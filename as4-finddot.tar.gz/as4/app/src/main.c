#include <stdio.h>
#include <stdlib.h>

#include "threadController.h"

int main ()
{
    printf("Hello CMPT433 Assignment4 Group: ALLIN_1!\n");
    startProgram();
    return 0;
}
